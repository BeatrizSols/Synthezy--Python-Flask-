# UsuarioDAO.py
# Correções:
# - Fecha cursores.
# - Inserir espera que usuario.senha já esteja com hash (padrão: hash no registration).
# - Autenticar busca pelo login (não compara senha no SQL); verificação de senha deve ser feita no código chamador com check_password_hash.

class UsuarioDAO:
    def __init__(self, con):
        self.con = con

    def Inserir(self, usuario):
        try:
            sql = "INSERT INTO usuario (login, senha, estado_login) VALUES (%s, %s, %s)"
            cursor = self.con.cursor()
            cursor.execute(sql, (usuario.login, usuario.senha, usuario.estado_login))
            self.con.commit()
            user_id = cursor.lastrowid
            cursor.close()
            return user_id
        except Exception as e:
            print("Erro ao inserir:", e)
            return -1

    def Autenticar(self, login):
        """
        Retorna a linha do usuário (id, login, senha, estado_login) ou None.
        A verificação do hash da senha deve ser feita fora (com check_password_hash).
        """
        try:
            cursor = self.con.cursor()
            cursor.execute("SELECT id, login, senha, estado_login FROM usuario WHERE login = %s", (login,))
            row = cursor.fetchone()
            cursor.close()
            return row
        except Exception as e:
            print("Erro ao autenticar:", e)
            return None

    def AtualizarEstadoLogin(self, id_usuario, estado):
        try:
            cursor = self.con.cursor()
            cursor.execute("UPDATE usuario SET estado_login = %s WHERE id = %s", (estado, id_usuario))
            self.con.commit()
            rowcount = cursor.rowcount
            cursor.close()
            return rowcount
        except Exception as e:
            print("Erro ao atualizar estado_login:", e)
            return 0
