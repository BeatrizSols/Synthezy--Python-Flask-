# Atividade.py
# Correções:
# - Adiciona id e usuario_id (existiam referências a atividade.id e atividade.usuario_id no DAO).
# - Métodos getters/setters.

class Atividade:
    def __init__(self, materia, data, horario, prioridade, status, comentario, usuario_id=0, id=0):
        self.id = id
        self.materia = materia
        self.data = data
        self.horario = horario
        self.prioridade = prioridade
        self.status = status
        self.comentario = comentario
        self.usuario_id = usuario_id

    def getCodigo(self):
        return self.id

    def setCodigo(self, codigo):
        self.id = codigo

    def getUsuario_id(self):
        return self.usuario_id

    def setUsuario_id(self, usuario_id):
        self.usuario_id = usuario_id
