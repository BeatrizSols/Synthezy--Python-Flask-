# Usuario.py
# Correções:
# - Inclui atributos id, login, senha e estado_login.
# - Métodos getters/setters consistentes com uso nos DAOs.

class Usuario:
    def __init__(self, login, senha, estado_login=0, id=0):
        self.id = id
        self.login = login
        self.senha = senha
        self.estado_login = estado_login

    def getCodigo(self):
        return self.id

    def setCodigo(self, codigo):
        self.id = codigo

    def getLogin(self):
        return self.login

    def setLogin(self, login):
        self.login = login

    def getSenha(self):
        return self.senha

    def setSenha(self, senha):
        self.senha = senha

    def getEstado_login(self):
        return self.estado_login

    def setEstado_login(self, estado_login):
        self.estado_login = estado_login
