# AtividadeDAO.py
# Correções:
# - Usa placeholders corretamente.
# - Fecha cursores.
# - Inclui ORDER BY em Listar (data, horario).
# - Mantém retorno consistente.

class AtividadeDAO:
    def __init__(self, con):
        self.con = con

    def Inserir(self, atividade):
        try:
            sql = """
                INSERT INTO atividade (`materia`, `data`, `horario`, `prioridade`, `status`, `comentario`, `usuario_id`)
                VALUES (%s, %s, %s, %s, %s, %s, %s)
            """
            cursor = self.con.cursor()
            cursor.execute(sql, (
                atividade.materia,
                atividade.data,
                atividade.horario,
                atividade.prioridade,
                atividade.status,
                atividade.comentario,
                atividade.usuario_id
            ))
            self.con.commit()
            last_id = cursor.lastrowid
            cursor.close()
            return last_id
        except Exception as e:
            print("Erro ao inserir atividade:", e)
            return 0

    def Listar(self, usuario_id, tipo="todos"):
        try:
            cursor = self.con.cursor()
            if tipo == "pendente":
                sql = "SELECT * FROM atividade WHERE status=%s AND usuario_id=%s ORDER BY data, horario"
                cursor.execute(sql, ("pendente", usuario_id))
            elif tipo == "concluido":
                sql = "SELECT * FROM atividade WHERE status=%s AND usuario_id=%s ORDER BY data, horario"
                cursor.execute(sql, ("concluido", usuario_id))
            else:
                sql = "SELECT * FROM atividade WHERE usuario_id=%s ORDER BY data, horario"
                cursor.execute(sql, (usuario_id,))
            rows = cursor.fetchall()
            cursor.close()
            return rows
        except Exception as e:
            print("Erro ao listar atividades:", e)
            return []

    def Editar(self, atividade):
        try:
            sql = """
                UPDATE atividade
                SET materia=%s, data=%s, horario=%s, prioridade=%s, status=%s, comentario=%s
                WHERE id=%s AND usuario_id=%s
            """
            cursor = self.con.cursor()
            cursor.execute(sql, (
                atividade.materia,
                atividade.data,
                atividade.horario,
                atividade.prioridade,
                atividade.status,
                atividade.comentario,
                atividade.id,
                atividade.usuario_id
            ))
            self.con.commit()
            rowcount = cursor.rowcount
            cursor.close()
            return rowcount
        except Exception as e:
            print("Erro ao editar atividade:", e)
            return 0

    def Excluir(self, id_atividade, usuario_id):
        try:
            sql = "DELETE FROM atividade WHERE id = %s AND usuario_id = %s"
            cursor = self.con.cursor()
            cursor.execute(sql, (id_atividade, usuario_id))
            self.con.commit()
            rowcount = cursor.rowcount
            cursor.close()
            return rowcount
        except Exception as e:
            print("Erro ao excluir atividade:", e)
            return 0
