# Bibliotecas + Imports
from flask import Flask, render_template, g, request, redirect, url_for, session, flash
from datetime import date, timedelta
import uuid
import os
import json
import mysql.connector
import requests
import ssl
import datetime
from models.Usuario import Usuario
from models.UsuarioDAO import UsuarioDAO
from models.Atividade import Atividade
from models.AtividadeDAO import AtividadeDAO
from flask_mysqldb import MySQL

from flask_mysqldb import MySQL
from MySQLdb.cursors import DictCursor
#  from werkzeug.security import generate_password_hash, check_password_hash (podemos inserir isso no próximo semestre para melhor segurança)

app = Flask(__name__)
app.debug = True
app.secret_key = 'chave_secreta'  

# Configurações do MySQL (usuário/senha do XAMPP)
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''  
app.config['MYSQL_DB'] = 'agenda_db'
# app.config['MYSQL_CURSORCLASS'] = 'DictCursor'  

mysql = MySQL(app)


# Home - Exibe atividades do usuário logado
@app.route('/')
def index(): 
    if 'usuario_id' not in session:
        return redirect(url_for('login'))
    lista_hor = horario() 

    usuario_id = session['usuario_id']
    busca = request.args.get('filtro', 'todas')

    cur = mysql.connection.cursor(DictCursor)
    try:
        query_base = "SELECT DISTINCT materia FROM atividade WHERE usuario_id = %s"
        cur.execute(query_base, (usuario_id,))
        materias = cur.fetchall()

    except:
        pass

    try:
        query_base = "SELECT * FROM atividade WHERE usuario_id = %s"
        if busca == 'pendente':
            query_base += " AND status = 'pendente'"
        elif busca == 'concluida':
            query_base += " AND status = 'concluida'"

        query_base += """
            ORDER BY CASE WHEN status = 'pendente' THEN 0 ELSE 1 END,
            prioridade ASC, data ASC, horario ASC
        """

        cur.execute(query_base, (usuario_id,))
        atividades = cur.fetchall()

        # Verificar se alguma atividade vence amanhã
        hoje = datetime.date.today()
        amanha = hoje + datetime.timedelta(days=1)

        for atividade in atividades:
            data_atividade = atividade['data']
            situação = atividade['status']
            
            # converter para .date() se for datetime
            if isinstance(data_atividade, (datetime.datetime, datetime.date)) and data_atividade.date() == amanha and situação == 'pendente':
                materia = atividade.get('materia') or atividade.get('titulo') or 'Atividade' 
                flash(f"⏰ Atenção: a atividade '{materia}' vence amanhã!", "warning")

    finally:
        cur.close()

    #Lista horarios

    if 'usuario_id' not in session:
        return redirect(url_for('login'))

    usuario_id = session['usuario_id']
    cur = mysql.connection.cursor()

    # Buscar horários do banco para o usuário
    cur.execute("""
        SELECT titulo, descricao, data, intervalo
        FROM horario
        WHERE usuario_id = %s
        ORDER BY data ASC, intervalo ASC
    """, (usuario_id,))
    horarios = cur.fetchall()

    dias_semana = ['Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta']
    horario_mapa = {}

    # Montar o mapa de horários para o template
    for titulo, descricao, data, intervalo in horarios:
        if data is None or intervalo is None:
            continue  # pular dados incompletos
        try:
            data_obj = datetime.datetime.strptime(str(data), '%Y-%m-%d').date()
        except ValueError:
            continue  # pular dados com data inválida

        dia_semana_index = data_obj.weekday()
        if 0 <= dia_semana_index <= 4:  # só dias úteis
            dia_semana = dias_semana[dia_semana_index]
            intervalo_formatado = converter_intervalo(intervalo)
            key = f"{intervalo_formatado}_{dia_semana}"
            horario_mapa[key] = f"{titulo} - {descricao}"

    if request.method == 'POST':
        titulo = request.form.get('titulo', '').strip()
        descricao = request.form.get('descricao', '').strip()
        dia = request.form.get('data', '').strip()
        intervalo = request.form.get('intervalo', '').strip()

        try:
            cur.execute("""
                INSERT INTO horario (titulo, descricao, data, intervalo, usuario_id)
                VALUES (%s, %s, %s, %s, %s)
            """, (titulo, descricao, dia, intervalo, usuario_id))
            mysql.connection.commit()
            flash('Atividade adicionada com sucesso!', 'success')
            return redirect(url_for('horario'))
        finally:
            cur.close()

    return render_template('index.html', atividades=atividades, filtro=busca, materias=materias, lista_hor=lista_hor, horario_mapa=horario_mapa, dias_semana=dias_semana)


# Cadastro de usuário
@app.route('/registrar', methods=['GET', 'POST'])
def registrar():
    if request.method == 'POST':
        login = request.form.get('login', '').strip()
        senha = request.form.get('senha', '').strip()

        if not login or not senha:
            flash('Por favor, preencha todos os campos.', 'info')
            return redirect(url_for('registrar'))

        cur = mysql.connection.cursor()
        try:
            cur.execute("SELECT id FROM usuario WHERE login = %s", (login,))
            usuario_existente = cur.fetchone()
            if usuario_existente:
                flash('Usuário já cadastrado.', 'info')
                return redirect(url_for('registrar'))

            senha_hash = senha  # senha pura agora  # ALTERADO
            cur.execute("INSERT INTO usuario (login, senha, estado_login) VALUES (%s, %s, %s)", (login, senha_hash, 0))
            mysql.connection.commit()
            flash('Usuário registrado com sucesso! Faça login.', 'success')
            return redirect(url_for('login'))
        finally:
            cur.close()

    return render_template('registrar.html')

# Login
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        login = request.form.get('login', '').strip()
        senha = request.form.get('senha', '').strip()

        if not login or not senha:
            flash('Por favor, preencha todos os campos.', 'info')
            return redirect(url_for('login'))

        cur = mysql.connection.cursor()
        try:
            cur.execute("SELECT id, senha FROM usuario WHERE login = %s", (login,))
            usuario = cur.fetchone()
        finally:
            cur.close()

        hashed = None
        user_id = None
        if usuario:
            if isinstance(usuario, dict):
                hashed = usuario.get('senha')
                user_id = usuario.get('id')
            else:
                user_id = usuario[0]
                hashed = usuario[1]

        # ALTERADO: comparação direta ao invés de check_password_hash
        if usuario and hashed and hashed == senha:
            session['usuario_id'] = user_id
            session['usuario_login'] = login

            cur = mysql.connection.cursor()
            try:
                cur.execute("UPDATE usuario SET estado_login = %s WHERE id = %s", (1, user_id))
                mysql.connection.commit()
            finally:
                cur.close()

            flash(f'Bem-vindo(a), {login}!', 'success')
            return redirect(url_for('index'))

        flash('Login ou senha incorretos.', 'info')
        return redirect(url_for('login'))

    return render_template('login.html')

# Logout
@app.route('/logout')
def logout():
    if 'usuario_id' in session:
        usuario_id = session['usuario_id']
        cur = mysql.connection.cursor()
        try:
            cur.execute("UPDATE usuario SET estado_login = %s WHERE id = %s", (0, usuario_id))
            mysql.connection.commit()
        finally:
            cur.close()

    session.clear()
    flash('Você saiu da conta.', 'info')
    return redirect(url_for('login'))

# Adicionar atividade
@app.route('/adicionar', methods=['GET', 'POST'])
def adicionar():
    if 'usuario_id' not in session:
        return redirect(url_for('login'))

    if request.method == 'POST':
        #materia = request.form.get('nova_materia', '').strip()
        materia_select = request.form.get('select_materia', '').strip()
        if materia_select == "zero":
            materia = request.form.get('nova_materia', '').strip()
        else:
            materia = materia_select
        print(materia)
        data = request.form.get('data', '').strip()
        horario = request.form.get('horario', '').strip()
        prioridade = request.form.get('prioridade', '').strip()
        status = request.form.get('status', 'pendente').strip()
        comentario = request.form.get('comentario', '').strip()
        usuario_id = session['usuario_id']

        if not materia or not data:
            flash('Preencha pelo menos matéria e data.', 'info')
            return redirect(url_for('adicionar'))

        cur = mysql.connection.cursor()
        try:
            def prioridade_valor(p):
                return {"Alta": 0, "Média": 1, "Baixa": 2}.get(p, 3)
            prioridade = prioridade_valor(prioridade)
            cur.execute("""
                INSERT INTO atividade (materia, data, horario, prioridade, status, comentario, usuario_id)
                VALUES (%s, %s, %s, %s, %s, %s, %s)
            """, (materia, data, horario, prioridade, status, comentario, usuario_id))
            mysql.connection.commit()
            flash('Atividade adicionada com sucesso!', 'success')
            return redirect(url_for('index'))
        finally:
            cur.close()

    return render_template('index.html')

@app.route("/delete/<id>")
def delete(id):
    if 'usuario_id' not in session:
        return redirect(url_for('login'))

    usuario_id = session['usuario_id']
    cur = mysql.connection.cursor()
    try:
        cur.execute("""
            DELETE FROM atividade
            WHERE id = %s AND usuario_id = %s
        """, (id, usuario_id))
        mysql.connection.commit()  # Commit na conexão, não no cursor
    finally:
        cur.close()

    return redirect(url_for("index"))

@app.route("/edit/<int:id>", methods=["GET", "POST"])
def edit(id):
    if 'usuario_id' not in session:
        return redirect(url_for('login'))

    usuario_id = session['usuario_id']
    cur = mysql.connection.cursor()
    try:
        # Buscar a atividade no banco
        cur.execute("""
            SELECT id, materia, data, horario, prioridade, status, comentario 
            FROM atividade 
            WHERE id = %s AND usuario_id = %s
        """, (id, usuario_id))
        atividade = cur.fetchone()
        if not atividade:
            flash('Atividade não encontrada ou acesso negado.', 'info')
            return redirect(url_for('index'))

        if request.method == "POST":
            materia = request.form.get("materia")
            data = request.form.get("data")
            print(data)
            horario = request.form.get("horario")
            prioridade = request.form.get("prioridade")
            comentario = request.form.get("comentario")

            def prioridade_valor(p):
                return {"Alta": 0, "Média": 1, "Baixa": 2}.get(p, 3)
            prioridade = prioridade_valor(prioridade)

            cur.execute("""
                UPDATE atividade
                SET materia = %s, data = %s, horario = %s, prioridade = %s, comentario = %s
                WHERE id = %s AND usuario_id = %s
            """, (materia, data, horario, prioridade, comentario, id, usuario_id))
            mysql.connection.commit()
            flash('Atividade atualizada com sucesso!', 'success')
            return redirect(url_for('index'))
    finally:
        cur.close()



    # A atividade retornada do banco é uma tupla, transformar dict para facilitar no template
    print(atividade[2])
    atividade_dict = {
        'id': atividade[0],
        'materia': atividade[1],
        'data': atividade[2].strftime('%Y-%m-%d'),
        'horario': atividade[3],
        'prioridade': atividade[4],
        'status': atividade[5],
        'comentario': atividade[6],
    }
    print(atividade_dict)
    return render_template("secunt.html", atividade=atividade_dict)


@app.route("/concluir/<id>")
def concluir(id):
    print(id)
    if 'usuario_id' not in session:
        return redirect(url_for('login'))

    usuario_id = session['usuario_id']
    cur = mysql.connection.cursor()
    try:
        cur.execute("""
            UPDATE atividade
            SET status = 'concluida'
            WHERE id = %s AND usuario_id = %s
        """, (id, usuario_id))
        mysql.connection.commit()  # Commit na conexão, não no cursor
    finally:
        cur.close()

    return redirect(url_for("index"))
#----------------------------------

# Função para converter intervalo de hora (ex: '07:00:00' -> '07:00 ~~ 08:00')
def converter_intervalo(hora_inicio_val):
    # Se for timedelta
    if isinstance(hora_inicio_val, datetime.timedelta):
        total_seconds = int(hora_inicio_val.total_seconds())
        horas = total_seconds // 3600
        minutos = (total_seconds % 3600) // 60
        segundos = total_seconds % 60
        hora_inicio_str = f"{horas:02d}:{minutos:02d}:{segundos:02d}"
    else:
        hora_inicio_str = hora_inicio_val  #é string

    hora_inicio = datetime.datetime.strptime(hora_inicio_str, '%H:%M:%S')
    hora_fim = hora_inicio + datetime.timedelta(hours=1)
    intervalo_str = f"{hora_inicio.strftime('%H:%M')} ~~ {hora_fim.strftime('%H:%M')}"
    return intervalo_str

@app.route('/horario', methods=['GET', 'POST'])
def horario():
    if 'usuario_id' not in session:
        return redirect(url_for('login'))

    usuario_id = session['usuario_id']
    cur = mysql.connection.cursor()

    # Buscar horários do banco para o usuário
    cur.execute("""
        SELECT titulo, descricao, data, intervalo
        FROM horario
        WHERE usuario_id = %s
        ORDER BY data ASC, intervalo ASC
    """, (usuario_id,))
    horarios = cur.fetchall()

    dias_semana = ['Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta']
    horario_mapa = {}

    # Montar o mapa de horários para o template
    for titulo, descricao, data, intervalo in horarios:
        if data is None or intervalo is None:
            continue  # pular dados incompletos
        try:
            data_obj = datetime.datetime.strptime(str(data), '%Y-%m-%d').date()
        except ValueError:
            continue  # pular dados com data inválida

        dia_semana_index = data_obj.weekday()
        if 0 <= dia_semana_index <= 4:  # só dias úteis
            dia_semana = dias_semana[dia_semana_index]
            intervalo_formatado = converter_intervalo(intervalo)
            key = f"{intervalo_formatado}_{dia_semana}"
            horario_mapa[key] = f"{titulo} - {descricao}"

    if request.method == 'POST':
        titulo = request.form.get('titulo', '').strip()
        descricao = request.form.get('descricao', '').strip()
        dia = request.form.get('data', '').strip()
        intervalo = request.form.get('intervalo', '').strip()

        try:
            cur.execute("""
                INSERT INTO horario (titulo, descricao, data, intervalo, usuario_id)
                VALUES (%s, %s, %s, %s, %s)
            """, (titulo, descricao, dia, intervalo, usuario_id))
            mysql.connection.commit()
            flash('Atividade adicionada com sucesso!', 'success')
            return redirect(url_for('horario'))
        finally:
            cur.close()

    return render_template('index.html', horario_mapa=horario_mapa, dias_semana=dias_semana)


if __name__ == '__main__':
    app.run(debug=True, host="0.0.0.0", port=5000)